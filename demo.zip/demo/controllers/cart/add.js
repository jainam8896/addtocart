const Cart = require("../../models/Cart")


const addItemToCart = async (req, res) => {
    const { productId, qty } = req.body
    const userId = req.user._id
    console.log("userId: -", userId);

    try {
        let cart = await Cart.findOne({ userId });
        if (cart) {
            //cart exists for user
            let itemIndex = cart.products.findIndex(p => p.productId == productId);

            if (itemIndex > -1) {
                let productItem = cart.products[itemIndex];
                if (qty > 0) {
                    //product exists in the cart, update the quantity
                    productItem.qty = qty;
                    cart.products[itemIndex] = productItem;
                } else {
                    cart.products.splice(itemIndex, 1)
                    console.log("Cart product", cart.products);
                }
            } else {
                //product does not exists in cart, add new item
                if (qty > 0) {

                    cart.products.push({ productId, qty });
                } else {
                    return res.status(400).json({ status: "fail", message: "Qty must be greater than 0" });
                }
            }
            cart = await cart.save();
            return res.status(201).send(cart);
        } else {
            //no cart for user, create new cart
            const newCart = await Cart.create({
                userId,
                products: [{ productId, qty }]
            });

            return res.status(201).send(newCart);
        }
    } catch (error) {
        console.log("error", error);
        res.status(500).send("Something went wrong");
    }
}

module.exports = addItemToCart