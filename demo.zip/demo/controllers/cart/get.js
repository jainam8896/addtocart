const Cart = require("../../models/Cart")

const getCart = async (req, res) => {
    let userId = req.user._id
    // let user = await User.exists({ _id: userId });

    // if (!userId || !isValidObjectId(userId) || !user)
    //     return res.status(400).send({ status: false, message: "Invalid user ID" });

    let cart = await Cart.findOne({ userId: userId });
    if (!cart)
        return res
            .status(404)
            .send({ status: false, message: "Cart not found for this user" });

    res.status(200).send({ status: true, cart: cart });
}

module.exports = getCart