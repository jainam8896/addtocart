const Product = require("../../models/Product");

//Create Product //  (req, res, next)
const createProduct = async (req, res) => {
  const { name, description, price, qty } =
    req.body;
  const product = await Product.findOne({ name: name });
  if (product) {
    return res.send({
      status: "failed",
      message: "Product Already Exists.....Please Enter Different Product",
    });
  }
  const newProduct = new Product({
    name: name,
    description: description,
    price: price,
    qty: qty,
    image: req.file.filename
  });
  await newProduct.save();
  res
    .status(200)
    .send({ status: "success", message: "Product Added Successfully" });
};

module.exports = createProduct;
