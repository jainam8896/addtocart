const Category = require("../../models/Category");
const { validationResult } = require("express-validator");

//Create user
const createCategory = async (req, res) => {
  try {
    const { name, parentId } = req.body;
    const category = await Category.findOne({ name: name });
    if (category) {
      return res.send({
        status: "failed",
        message: "Category Already Exists.....",
      });
    }
    const newCategory = new Category({
      name: name,
      parentId: parentId,
    });
    await newCategory.save();
    res
      .status(200)
      .send({ status: "success", message: "Category Added Successfully" });
  } catch (error) {
    res.json(error);
  }
};

module.exports = createCategory;
