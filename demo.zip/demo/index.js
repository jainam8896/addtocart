require("dotenv").config({});
const express = require("express")
const app = express();
const connectDB = require("./services/database");
const ErrorHandler = require("./middlewares/errorHandler")
const port = process.env.PORT || 3000;
app.use(express.json());

//API
app.use("/api/v1", require("./routes/index.routes"));

app.use(ErrorHandler)

app.listen(port, () => {
    console.log(`Server Is Running On Port ${port}`);
    connectDB()

})