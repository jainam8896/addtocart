const { body } = require("express-validator");

const categoryValidation = [
  body("name").notEmpty().withMessage("Category name is required"),
  // body("parentId").notEmpty().withMessage("Parent id is required"),
];

module.exports = {categoryValidation}
