const express = require("express");
const router = express.Router();
const auth = require("../middlewares/auth");

router.use("/authentication", require("./authentication.routes.js"));
router.use("/categories", require("./category.routes.js"));
router.use("/products", require("./product.routes.js"));

router.use(auth);
router.use("/cart",require("./cart.routes.js"))
router.use("/users", require("./users.routes.js"));


module.exports = router;
