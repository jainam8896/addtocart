const express = require("express");
const router = express.Router();
// const auth = require("../middlewares/auth");
const deleteUser = require("../controllers/users/delete");
const getUser = require("../controllers/users/get");
const updateUser = require("../controllers/users/update");
const upload = require("../helper/userimageupload");

//Delete User
router.delete("/:id", deleteUser);

//Get User
router.get("/:id", getUser);

//Update User
router.put("/:id", upload.single("profileimage"), updateUser);

module.exports = router;
