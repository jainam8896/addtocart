const express = require("express");
const router = express.Router();
const addItemToCart = require("../controllers/cart/add")
const getCart = require("../controllers/cart/get")

router.post("/add", addItemToCart);
router.get("/",getCart)

module.exports = router;